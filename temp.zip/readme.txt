copy paste these 2 folders into
steamapps\common\Counter-Strike Global Offensive\csgo\sound